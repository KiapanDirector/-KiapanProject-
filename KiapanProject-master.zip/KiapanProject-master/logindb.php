<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="194x194" href="favicon/favicon-194x194.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
	<link rel="manifest" href="favicon/site.webmanifest">
	<link rel="mask-icon" href="favicon/safari-pinned-tab.svg" color="#000000">
	<link rel="shortcut icon" href="favicon/favicon.ico">
	<meta name="apple-mobile-web-app-title" content="Kiapan Project">
	<meta name="application-name" content="Kiapan Project">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
	<meta name="msapplication-config" content="favicon/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	<title> The Kiapan Project: Signup </title>
	<link rel="stylesheet" type="text/css" href="css/common.css">
	<link rel="stylesheet" type="text/css" href="css/login.php.css">
</head>
<body>
	<div id="container">
		<div id="title">
			<h1><strong><a href="index.html">开盘</a></strong></h1>
		</div>
		<div id="subtitle">
			<h3 class="mini-title"> Kiapan Project </h3>
		</div>
		<div id="subtitler">
			<h3 class="mini-title"> Congratulations on your return. </h3>
		</div>
		<div id="result">
			<?php
				include "utils.php";

				session_start();

				// make sure POST request is a-ok
				if(!isset($_POST["username"]) || !isset($_POST["password"]))
					diee("You missed an input prompt.");

				$conn = db_connect();
				$stmt = $conn->prepare("SELECT password, id, admin FROM users WHERE username = ?");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("s", $_POST["username"]);
				$stmt->execute();
				$stmt->bind_result($real_pass, $id, $isadmin);
				$stmt->fetch();

				if(password_verify($_POST["password"], $real_pass)) {
					$_SESSION["username"] = $_POST["username"];
					$_SESSION["id"] = $id;
					$_SESSION["isadmin"] = $isadmin;
					header("Location: chat.php");
					$stmt->close();
					$conn->close();
					clearchat();
				} else {
					$stmt->close();
					$conn->close();
					clearchat();
					diee("Your username or password is incorrect!");	
				}
			?>
		</div>
	</div>
</body>
</html>