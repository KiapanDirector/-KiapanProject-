<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="194x194" href="favicon/favicon-194x194.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
	<link rel="manifest" href="favicon/site.webmanifest">
	<link rel="mask-icon" href="favicon/safari-pinned-tab.svg" color="#000000">
	<link rel="shortcut icon" href="favicon/favicon.ico">
	<meta name="apple-mobile-web-app-title" content="Kiapan Project">
	<meta name="application-name" content="Kiapan Project">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
	<meta name="msapplication-config" content="favicon/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	<title> The Kiapan Project: Signup </title>
	<link rel="stylesheet" type="text/css" href="css/common.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
	<div id="container">
		<?php
			session_start();
			
			if(isset($_SESSION["id"]))
				header("Location: chat.php");
		?>
		<div id="title">
			<h1><strong><a href="index.html">开盘</a></strong></h1>
		</div>
		<div id="subtitle">
			<h3 class="mini-title"> Kiapan Project </h3>
		</div>
		<div id="subtitler">
			<h3 class="mini-title"> Congratulations on your return. </h3>
		</div>
		<form action="logindb.php" method="post" id="loginform"></form>
			<div id="usernamelabel">
				<label for="username"><h3 class="mini-title blue underlined"> Username </h3></label>
			</div>
			<div id="usernameinput">
				<input type="text" name="username" minlength="4" maxlength="64" form="loginform" required>
			</div>
			<div id="passwordlabel">
				<label for="password"><h3 class="mini-title blue underlined"> Password </h3></label>
			</div>
			<div id="passwordinput">
				<input type="password" name="password" minlength="8" maxlength="128" form="loginform" required>
			</div>
			<div id="submitinput">
				<input type="submit" name="submit" value="Login" form="loginform">
			</div>
	</div>
</body>
</html>