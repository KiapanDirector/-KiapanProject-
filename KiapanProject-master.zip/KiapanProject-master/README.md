# KiapanProject

## Mission

## Technical Details
### GFCs
The Kiapan Project chat room requires a registration to be made via a GFC (General Filter Code). Those GFCs are distributed by the Staff and are one time use. They consist of 64 random alphanumeric characters. They are stored in a SQL database so that they can be used only once and so that there is no duplication.
### Chat
The chatroom is written in PHP and JS. It is currently limited to 1024 people at a time. The message limit is 512 characters and there is a maximum of 2048 characters per 5 minute. To prevent spam, a user cannot post more than 2048 characters per 5 minutes, meaning that everytime they post, the server checks to see if they have posted more than 2048 characters in the last 5 minutes. If they have, the server locks them out for 5 additional minutes. Messages are kept for an hour and then deleted.
### E-Mails
E-Mails are only stored for password recovery purposes.
### Database Setup
For database setup, see `db.sql`. The actual db connection details are set up in `utils.php`.