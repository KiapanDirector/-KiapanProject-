<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="194x194" href="favicon/favicon-194x194.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
	<link rel="manifest" href="favicon/site.webmanifest">
	<link rel="mask-icon" href="favicon/safari-pinned-tab.svg" color="#000000">
	<link rel="shortcut icon" href="favicon/favicon.ico">
	<meta name="apple-mobile-web-app-title" content="Kiapan Project">
	<meta name="application-name" content="Kiapan Project">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
	<meta name="msapplication-config" content="favicon/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	<title> The Kiapan Project: Chat </title>
	<link rel="stylesheet" type="text/css" href="css/common.css">
	<link rel="stylesheet" type="text/css" href="css/chat.css">
</head>
<body>
	<div id="container">
		<?php
			session_start();

			if(!isset($_SESSION["id"]))
				header("Location: login.php");
		?>
		<div id="title">
			<h1> <a href="index.html"> 开盘 </a> </h1>
			<p id="en-title"> Kiapan Project </p>
		</div>
		<div id="welcome">
			<h1> MOTD: </h2>
		</div>
		<div id="chatwindow">
			
		</div>
		<div id="onlinewindow">
			<h2> Online: </h2>
			<ul id="onlinelist"></ul>
			<a href="logout.php" class="red" id="logout"> Log Out </a>
		</div>
		<div id="writingwindow">
			<input type="text" name="chat" id="chat" size="512">
		</div>
	</div>
</body>
</html>