# Requirements

## Chatroom

 * Max 512 chars
 * Disappears after an hour
 * 

## Auth

 * Unique signup code required
 * 

## Design
 * Spooky layout "to scare of reddit faggots"
 * 