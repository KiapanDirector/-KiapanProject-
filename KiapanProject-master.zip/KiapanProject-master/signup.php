<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="194x194" href="favicon/favicon-194x194.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
	<link rel="manifest" href="favicon/site.webmanifest">
	<link rel="mask-icon" href="favicon/safari-pinned-tab.svg" color="#000000">
	<link rel="shortcut icon" href="favicon/favicon.ico">
	<meta name="apple-mobile-web-app-title" content="Kiapan Project">
	<meta name="application-name" content="Kiapan Project">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
	<meta name="msapplication-config" content="favicon/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	<title> The Kiapan Project: Signup </title>
	<link rel="stylesheet" type="text/css" href="css/common.css">
	<link rel="stylesheet" type="text/css" href="css/signup.php.css">
</head>
<body>
	<div id="container">
		<div id="title">
			<h1><strong><a href="index.html">开盘</a></strong></h1>
		</div>
		<div id="subtitle">
			<h3 class="mini-title"> Kiapan Project </h3>
		</div>
		<div id="subtitler">
			<h3 class="mini-title"> Create an account: </h3>
		</div>
		<div id="result">
			<?php
				include "utils.php";

				// make sure POST request is a-ok
				if(!isset($_POST["gfc"]) || !isset($_POST["username"]) || !isset($_POST["email"]) || !isset($_POST["password"]))
					diee("You missed an input prompt.");
				if(strlen($_POST["gfc"]) != 64)
					diee("The GFC needs to be 64 characters long.");
				if(strlen($_POST["username"]) < 4)
					diee("The username is too short. Make it at least 4 characters.");
				if(strlen($_POST["password"]) < 8)
					diee("The password is too short. Make it at least 8 characters.");
				if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))
					diee("The email is invalid.");

				// check to see if gfc is valid and unused
				$conn = db_connect();
				$stmt = $conn->prepare("SELECT COUNT(1) FROM gfcs WHERE gfc = ? AND used = 0");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("s", $_POST["gfc"]);
				$stmt->execute();
				$stmt->bind_result($isgfcavaialble);
				$stmt->fetch();
				if($isgfcavaialble < 1)
					diee("This GFC is either invalid or has already been used.");
				$stmt->close();

				//check to see if email exists
				$stmt = $conn->prepare("SELECT COUNT(1) FROM users WHERE email = ?");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("s", $_POST["email"]);
				$stmt->execute();
				$stmt->bind_result($isemailavailable);
				$stmt->fetch();
				if($isemailavailable > 0)
					diee("This email has already been used.");
				$stmt->close();

				//check to see if username exists
				$stmt = $conn->prepare("SELECT COUNT(1) FROM users WHERE username = ?");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("s", $_POST["username"]);
				$stmt->execute();
				$stmt->bind_result($isusernameavailable);
				$stmt->fetch();
				if($isusernameavailable > 0)
					diee("This username has already been used.");
				$stmt->close();

				//all is good, time to register the user and mark the gfc as used
				$stmt = $conn->prepare("SELECT id FROM gfcs WHERE gfc = ?");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("s", $_POST["gfc"]);
				$stmt->execute();
				$stmt->bind_result($gfc);
				$stmt->fetch();
				$stmt->close();
				$stmt = $conn->prepare("UPDATE gfcs SET used = 1 WHERE id = ?");
				if(!$stmt)
					diee("Something went wrong internaly. Please try again later.");
				$stmt->bind_param("i", $gfc);
				$stmt->execute();
				$stmt->close();
				$stmt = $conn->prepare("INSERT INTO users (username, email, password, gfc) VALUES (?, ?, ?, ?)");
				$hashedpassword = password_hash($_POST["password"], PASSWORD_DEFAULT);
				$stmt->bind_param("sssi", $_POST["username"], $_POST["email"], $hashedpassword, $gfc);
				$stmt->execute();
				$stmt->close();

				$conn->close();
				diee("You have been successfully registered. Welcome to Kiapan.");
			?>
		</div>
	</div>
</body>
</html>