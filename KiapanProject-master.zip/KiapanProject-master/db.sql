CREATE DATABASE kiapanproject CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `kiapanproject`.`users` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8_bin NOT NULL,
  `email` varchar(512) COLLATE utf8_bin NOT NULL,
  `password` varchar(512) COLLATE utf8_bin NOT NULL,
  `gfc` int(11) NOT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `kiapanproject`.`gfcs` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`gfc` VARCHAR(256) NOT NULL,
	`used` INT NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `chat` (
  	`id` int(11) NOT NULL,
  	`chat` varchar(2048) COLLATE utf8_bin NOT NULL,
  	`bywho` int(11) NOT NULL,
  	`when` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `gfc`, `admin`) VALUES (
	'0', '<admin username>',
	'<admin email>', '<bcrypt hash of admin password>',
	'0', '1');

INSERT INTO `gfcs` (`id`, `gfc`, `used`, `bywho`) VALUES (
	'0',
	'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
	'1', '0');