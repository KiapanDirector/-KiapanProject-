<?php
	function db_connect() {
		$db_servername = "localhost";
		$db_username = "root";
		$db_password = "";
		$db_name = "kiapanproject";
		$conn = new mysqli($db_servername, $db_username, $db_password, $db_name);
		if($conn->connect_error) {
			die("<h3 class=\"mini-title red\"> Connection failed! </h3>");
		}

		return $conn;
	}

	function diee($str) {
		die("<h3 class=\"mini-title red\"> " . $str . " </h3>");
	}

	function clearchat() {
		$conn = $db_connect();
		$stmt->prepare("DELETE FROM chat WHERE TIMESTAMPDIFF(minute, `when`, CURRENT_TIMESTAMP) > 30");
		$stmt->execute();
		$stmt->close();
		$conn->close();
	}
?>