window.onload = function() {
	document.getElementById("music").volume = 0.1;
}